Eutil = require('ethereumjs-util');
EcommerceStore = artifacts.require("./EcommerceStore.sol");
module.exports = function(callback) {
    current_time = Math.round(new Date() / 1000);
    amt_1 = web3.utils.toWei('1', 'ether');
    EcommerceStore.deployed().then(i=>(i.addProductToStore('iPhone 8','cell phone','QmPDWb5XXaSD4GA5i16KReQBab7RBxqe7no8USJrW4CyRQ','Qmc7cPq4igPB1oqyJQze79XpPXJ8xmNDkuhXbjxGaLqKma',current_time, current_time + 600,amt_1,0).then(console.log)));
    EcommerceStore.deployed().then(i=>(i.addProductToStore('iPhone 13','cell phone','QmZ6ZyTY2Y77unf49Lnx6gpu4f29e1ioV6yy71qRADLX9n','QmQ1dEM1hEYHhVBoAfhhtwYfZuw5wsLCWtkMTViEfgKewW',current_time, current_time + 600,amt_1,0).then(console.log)));
    EcommerceStore.deployed().then(i=>(i.addProductToStore('sonyx1m3','cell phone','QmcndbckY96DHU1cWhabyaWzrDG818E4DsATvAC7xJFPdf','QmaBYA8HVHDg8Lh4Y42z31TkDZmfkPPfcdpvjdhEYFCQWJ',current_time, current_time + 600,amt_1,0).then(console.log)));
    EcommerceStore.deployed().then(i=>(i.addProductToStore('sonyxzp','cell phone','QmeCj8qUkKg1ugRHFjK5nzQ9BsaQH7SmGrg8BazgwiGhSC','QmeCFo4mr6jo4bGNhH4M5NYspHe58ruLLSNiN1PNiU2h88',current_time, current_time + 600,amt_1,0).then(console.log)));
    EcommerceStore.deployed().then(function(i) {i.productIndex.call().then(function(f){console.log(f)})});
}
